<?php

/**
 * 支付接口配置
 */

return [
    
    'name' => '支付宝',
    'icon' => '<i class="icon iconfont icon-rectangle390"></i>',
    
];