<div class="form-group">
    <label class="col-md-2 control-label">描述模板</label>
    <div class="col-md-9">
        <p class="form-control-static"> ./config/pay/paymeet.html </p>
    </div>
</div>
<div class="form-group">
    <label class="col-md-2 control-label">付款流程</label>
    <div class="col-md-9">
        <p class="form-control-static"> 用户提交付款请求并填写联系人详细地址和电话 -> 平台派人上门收款</p>
    </div>
</div>