<?php namespace Phpcmf\Controllers\Admin;

class Member extends \Phpcmf\Admin\Member
{

	public function index() {
		$this->_Index();
	}
}
