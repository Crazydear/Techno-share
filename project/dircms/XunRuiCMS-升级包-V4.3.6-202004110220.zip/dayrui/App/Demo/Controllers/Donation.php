<?php namespace Phpcmf\Controllers;

class Donation extends \Phpcmf\Home\Module
{
	public function index() {
		$this->_Donation();
	}

}
