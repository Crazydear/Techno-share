<?php

return [

    'type' => 'module',
    'name' => '租房',
    'icon' => 'fa fa-home',
    'system' => '1',

];